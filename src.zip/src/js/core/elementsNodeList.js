import {getElement} from "./index.js";


const html = document.documentElement;
const body = document.body;
const header = document.querySelector('header');



export {
    html,
    body,
    header,
};